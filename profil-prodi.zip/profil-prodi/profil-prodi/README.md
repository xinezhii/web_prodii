# Website Profil Program Studi (Express.js)

Panduan lengkap dari nol sampai upload ke GitHub, untuk **Tugas Mandiri sebelum Pertemuan 4**.
Hanya memakai **Express (Node.js)**, tanpa Laravel.

---

## Daftar Isi

1. [Gambaran Proyek](#1-gambaran-proyek)
2. [Persiapan & Cek Environment](#2-persiapan--cek-environment)
3. [Membuat Folder & Inisialisasi Proyek](#3-membuat-folder--inisialisasi-proyek)
4. [Struktur Folder](#4-struktur-folder)
5. [Kode Lengkap (Salin Satu per Satu)](#5-kode-lengkap-salin-satu-per-satu)
6. [Menjalankan & Menguji Website](#6-menjalankan--menguji-website)
7. [Bagian yang Bisa Anda Ganti (Foto & Konten)](#7-bagian-yang-bisa-anda-ganti-foto--konten)
8. [Screenshot yang Harus Dikumpulkan](#8-screenshot-yang-harus-dikumpulkan)
9. [Upload ke GitHub](#9-upload-ke-github)
10. [Pengumpulan di LMS & Checklist](#10-pengumpulan-di-lms--checklist)
11. [Troubleshooting](#11-troubleshooting)

---

## 1. Gambaran Proyek

Website ini dibuat dengan **Express** + **EJS** (template engine, supaya HTML bisa diisi data dari JavaScript).

### Route yang dibuat (sesuai soal)

| Route | Keterangan | Method |
|---|---|---|
| `/` dan `/profil` | Beranda, visi dan misi | GET |
| `/dosen?keahlian=...` | Daftar dosen + filter keahlian (form filter) | GET |
| `/dosen/:nidn` | Detail dosen. NIDN harus **10 digit angka**, selain itu **404** | GET |
| `/berita/:kategori?` | Berita per kategori. Jika kategori kosong, default `terbaru` | GET |
| `/admin/dashboard`, `/admin/pengaturan` | Grup route dengan prefix `/admin` | GET |
| `/api/dosen` | Response JSON | GET |
| URL lain | Halaman 404 kustom | - |
| `/kontak` *(tambahan)* | Halaman form kontak | GET, POST |

> Halaman yang bisa dibuka di browser: Beranda, Dosen, Detail Dosen, Berita, Kontak (form), Dashboard, Pengaturan, dan 404. Itu sudah lebih dari syarat minimal 3 halaman. Ada dua halaman berisi form: filter dosen dan form kontak.

### Konsep penting

- **Route**: pasangan URL dan fungsi yang menanganinya (`router.get('/dosen', ...)`).
- **Route parameter**: bagian URL yang berubah, ditulis `:nidn`. Tanda `?` seperti `:kategori?` artinya opsional.
- **Query string**: bagian setelah `?` di URL, misalnya `?keahlian=Basis Data`, dibaca lewat `req.query`.
- **Router & prefix**: `app.use('/admin', adminRoutes)` membuat semua route di file admin otomatis diawali `/admin`.
- **Middleware 404**: dipasang paling bawah. Jika tidak ada route yang cocok, request jatuh ke sini.

---

## 2. Persiapan & Cek Environment

Buka **VS Code**, lalu buka terminal: menu **Terminal → New Terminal** (atau tekan `` Ctrl + ` ``).

Jalankan satu per satu:

```bash
node -v
npm -v
git --version
```

Hasil yang diharapkan: masing-masing menampilkan nomor versi (contoh `v20.x.x`, `10.x.x`, `git version 2.x.x`).

- Jika `node` / `npm` tidak dikenali: instal Node.js LTS dari https://nodejs.org lalu **restart VS Code**.
- Jika `git` tidak dikenali: instal dari https://git-scm.com lalu restart VS Code.

Atur identitas Git (cukup sekali di komputer Anda, ganti dengan data Anda):

```bash
git config --global user.name "Nama Anda"
git config --global user.email "emailgithub@anda.com"
```

> Ambil **screenshot** hasil `node -v`, `npm -v`, dan `git --version`. Nanti ditambah screenshot `npm run cek` (bagian 8).

---

## 3. Membuat Folder & Inisialisasi Proyek

Kita membuat **satu folder repo** bernama `profil-prodi`. Di dalamnya ada folder `express/` (sesuai permintaan soal: folder `express/` dan `laravel/`; karena Laravel tidak dipakai, cukup `express/`).

```bash
mkdir profil-prodi
cd profil-prodi
mkdir express
cd express
```

Lalu di VS Code pilih **File → Open Folder** dan buka folder `profil-prodi` agar semua file terlihat di panel kiri. Pastikan terminal berada di folder `express`:

```bash
cd express
```

(Jika terminal sudah ada di dalam `profil-prodi`, jalankan `cd express`.)

Inisialisasi proyek Node dan instal library:

```bash
npm init -y
npm install express@4 ejs
```

- `npm init -y`: membuat file `package.json` (data proyek).
- `express@4`: framework web. Kita pakai versi 4 agar cocok dengan semua kode di panduan ini.
- `ejs`: template engine untuk file `.ejs`.

Buka `package.json`, lalu ubah bagian `"scripts"` menjadi seperti ini (bagian lain biarkan):

```json
"scripts": {
  "start": "node app.js",
  "dev": "node --watch app.js",
  "cek": "node cek-environment.js",
  "routes": "node routes-list.js"
},
```

- `npm start`: menjalankan server.
- `npm run dev`: menjalankan server dan otomatis restart saat file berubah (butuh Node 18.11+).
- `npm run cek`: cek environment (untuk screenshot).
- `npm run routes`: menampilkan daftar route (untuk screenshot, setara `route:list` di Laravel).

---

## 4. Struktur Folder

Buat folder dan file sesuai pohon berikut (klik kanan di panel Explorer VS Code → *New Folder* / *New File*):

```
profil-prodi/
├── .gitignore
├── README.md
└── express/
    ├── app.js
    ├── cek-environment.js
    ├── routes-list.js
    ├── package.json
    ├── data/
    │   ├── prodi.js
    │   ├── dosen.js
    │   └── berita.js
    ├── routes/
    │   ├── web.js
    │   ├── admin.js
    │   └── api.js
    ├── views/
    │   ├── partials/
    │   │   ├── header.ejs
    │   │   └── footer.ejs
    │   ├── admin/
    │   │   ├── dashboard.ejs
    │   │   └── pengaturan.ejs
    │   ├── beranda.ejs
    │   ├── dosen.ejs
    │   ├── dosen-detail.ejs
    │   ├── berita.ejs
    │   ├── kontak.ejs
    │   └── 404.ejs
    └── public/
        ├── css/
        │   └── style.css
        └── img/
            ├── placeholder.svg
            ├── logo.png          <- foto Anda (opsional)
            ├── hero.jpg          <- foto Anda (opsional)
            └── dosen/
                ├── dosen-1.jpg   <- foto Anda (opsional)
                └── ...
```

> `node_modules/` akan muncul otomatis setelah `npm install`. Jangan dibuat manual dan **jangan di-upload** ke GitHub.

---

## 5. Kode Lengkap (Salin Satu per Satu)

Semua path di bawah relatif terhadap folder `express/`.

### 5.1 `app.js`: pintu masuk aplikasi

```js
const express = require('express');
const path = require('path');

const webRoutes = require('./routes/web');
const adminRoutes = require('./routes/admin');
const apiRoutes = require('./routes/api');
const prodi = require('./data/prodi');

const app = express();
const PORT = process.env.PORT || 3000;

// Pengaturan template engine EJS
app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'views'));

// File statis (css, gambar) diambil dari folder public
app.use(express.static(path.join(__dirname, 'public')));

// Agar data dari <form method="POST"> bisa dibaca lewat req.body
app.use(express.urlencoded({ extended: true }));

// Data yang otomatis tersedia di semua file .ejs
app.use((req, res, next) => {
  res.locals.prodi = prodi;
  res.locals.path = req.path; // dipakai untuk menandai menu aktif
  next();
});

// Grup route
app.use('/admin', adminRoutes); // -> /admin/dashboard, /admin/pengaturan
app.use('/api', apiRoutes);     // -> /api/dosen
app.use('/', webRoutes);        // -> /, /profil, /dosen, /berita, /kontak

// 404 kustom: harus PALING BAWAH, menangkap semua URL yang tidak cocok
app.use((req, res) => {
  res.status(404).render('404', { judul: 'Halaman Tidak Ditemukan' });
});

module.exports = app;

// Server hanya jalan jika file ini dieksekusi langsung (node app.js)
if (require.main === module) {
  app.listen(PORT, () => {
    console.log(`Server berjalan di http://localhost:${PORT}`);
  });
}
```

### 5.2 `data/prodi.js`: identitas, visi, dan misi

```js
// Ubah isi file ini sesuai program studi Anda
module.exports = {
  nama: 'Teknik Informatika',
  singkatan: 'TI',
  fakultas: 'Fakultas Teknik',
  kampus: 'Universitas Contoh',
  alamat: 'Jl. Contoh No. 1, Samarinda, Kalimantan Timur',
  email: 'ti@universitascontoh.ac.id',
  telepon: '(0541) 000000',
  visi:
    'Menjadi program studi unggulan yang menghasilkan lulusan kompeten, inovatif, dan berdaya saing di bidang teknologi informasi.',
  misi: [
    'Menyelenggarakan pendidikan yang berkualitas dan sesuai kebutuhan industri.',
    'Melaksanakan penelitian yang bermanfaat bagi pengembangan ilmu dan masyarakat.',
    'Melaksanakan pengabdian kepada masyarakat berbasis teknologi.',
    'Membangun kerja sama dengan industri, pemerintah, dan perguruan tinggi lain.',
  ],
};
```

### 5.3 `data/dosen.js`: data dosen

```js
// NIDN harus 10 digit angka.
// "foto" = nama file di folder public/img/dosen/
// GANTI FOTO: taruh foto dosen di express/public/img/dosen/ lalu samakan nama filenya di sini.
module.exports = [
  {
    nidn: '0012058801',
    nama: 'Dr. Andi Pratama, M.Kom.',
    keahlian: 'Pemrograman Web',
    email: 'andi@universitascontoh.ac.id',
    bio: 'Mengajar pemrograman web dan rekayasa perangkat lunak. Aktif meneliti pengembangan aplikasi berbasis web.',
    foto: 'dosen-1.jpg',
  },
  {
    nidn: '0023077902',
    nama: 'Siti Rahmawati, M.T.',
    keahlian: 'Basis Data',
    email: 'siti@universitascontoh.ac.id',
    bio: 'Mengajar basis data dan sistem informasi. Fokus penelitian pada data warehouse.',
    foto: 'dosen-2.jpg',
  },
  {
    nidn: '0034098503',
    nama: 'Budi Santoso, M.Cs.',
    keahlian: 'Jaringan Komputer',
    email: 'budi@universitascontoh.ac.id',
    bio: 'Mengajar jaringan komputer dan keamanan siber. Berpengalaman sebagai network engineer.',
    foto: 'dosen-3.jpg',
  },
  {
    nidn: '0045118204',
    nama: 'Dewi Lestari, Ph.D.',
    keahlian: 'Kecerdasan Buatan',
    email: 'dewi@universitascontoh.ac.id',
    bio: 'Mengajar kecerdasan buatan dan pembelajaran mesin. Aktif menulis jurnal internasional.',
    foto: 'dosen-4.jpg',
  },
  {
    nidn: '0056089005',
    nama: 'Rizky Maulana, M.Kom.',
    keahlian: 'Pemrograman Web',
    email: 'rizky@universitascontoh.ac.id',
    bio: 'Mengajar pemrograman mobile dan web. Pembina komunitas pengembang kampus.',
    foto: 'dosen-5.jpg',
  },
];
```

### 5.4 `data/berita.js`: data berita

```js
// kategori yang valid: akademik, prestasi, kegiatan
// "terbaru" = semua berita (default)
module.exports = [
  {
    judul: 'Pendaftaran Mahasiswa Baru Dibuka',
    kategori: 'akademik',
    tanggal: '2026-10-01',
    ringkasan: 'Pendaftaran mahasiswa baru gelombang kedua telah dibuka hingga akhir bulan.',
  },
  {
    judul: 'Mahasiswa Juara 1 Lomba Pemrograman Nasional',
    kategori: 'prestasi',
    tanggal: '2026-09-20',
    ringkasan: 'Tim mahasiswa berhasil meraih juara pertama pada kompetisi tingkat nasional.',
  },
  {
    judul: 'Workshop Pengembangan Web Modern',
    kategori: 'kegiatan',
    tanggal: '2026-09-12',
    ringkasan: 'Workshop dua hari membahas Node.js, Express, dan deployment aplikasi.',
  },
  {
    judul: 'Jadwal Ujian Tengah Semester Dirilis',
    kategori: 'akademik',
    tanggal: '2026-09-05',
    ringkasan: 'Jadwal UTS semester ganjil sudah dapat dilihat oleh mahasiswa.',
  },
];
```

### 5.5 `routes/web.js`: route halaman publik

```js
const express = require('express');
const router = express.Router();

const dosen = require('../data/dosen');
const berita = require('../data/berita');

// 1) Beranda: dua URL menuju halaman yang sama
router.get(['/', '/profil'], (req, res) => {
  res.render('beranda', { judul: 'Beranda' });
});

// 2) Daftar dosen + filter keahlian: /dosen?keahlian=Basis Data
router.get('/dosen', (req, res) => {
  const keahlian = (req.query.keahlian || '').trim();

  const daftarKeahlian = [...new Set(dosen.map((d) => d.keahlian))];

  const hasil = keahlian
    ? dosen.filter((d) => d.keahlian.toLowerCase() === keahlian.toLowerCase())
    : dosen;

  res.render('dosen', {
    judul: 'Dosen',
    dosen: hasil,
    daftarKeahlian,
    keahlianDipilih: keahlian,
  });
});

// 3) Detail dosen: NIDN harus tepat 10 digit angka, selain itu 404
router.get('/dosen/:nidn', (req, res, next) => {
  const { nidn } = req.params;

  if (!/^\d{10}$/.test(nidn)) return next(); // bukan 10 digit -> 404

  const d = dosen.find((x) => x.nidn === nidn);
  if (!d) return next(); // 10 digit tapi tidak ada datanya -> 404

  res.render('dosen-detail', { judul: d.nama, d });
});

// 4) Berita: /berita atau /berita/prestasi. Default "terbaru"
router.get('/berita/:kategori?', (req, res, next) => {
  const kategori = (req.params.kategori || 'terbaru').toLowerCase();
  const kategoriValid = ['terbaru', 'akademik', 'prestasi', 'kegiatan'];

  if (!kategoriValid.includes(kategori)) return next(); // kategori asing -> 404

  const daftar =
    kategori === 'terbaru'
      ? berita
      : berita.filter((b) => b.kategori === kategori);

  res.render('berita', { judul: 'Berita', kategori, kategoriValid, daftar });
});

// 5) Halaman form kontak (tambahan)
router.get('/kontak', (req, res) => {
  res.render('kontak', { judul: 'Kontak', terkirim: false, data: {} });
});

router.post('/kontak', (req, res) => {
  const { nama, email, pesan } = req.body;
  console.log('Pesan masuk:', { nama, email, pesan });
  res.render('kontak', { judul: 'Kontak', terkirim: true, data: { nama } });
});

module.exports = router;
```

### 5.6 `routes/admin.js`: grup dengan prefix `/admin`

```js
const express = require('express');
const router = express.Router();

const dosen = require('../data/dosen');
const berita = require('../data/berita');

// Karena dipasang dengan app.use('/admin', ...), URL aslinya jadi /admin/dashboard
router.get('/dashboard', (req, res) => {
  res.render('admin/dashboard', {
    judul: 'Dashboard Admin',
    totalDosen: dosen.length,
    totalBerita: berita.length,
  });
});

router.get('/pengaturan', (req, res) => {
  res.render('admin/pengaturan', { judul: 'Pengaturan Admin' });
});

module.exports = router;
```

### 5.7 `routes/api.js`: response JSON

```js
const express = require('express');
const router = express.Router();

const dosen = require('../data/dosen');

// GET /api/dosen  atau  /api/dosen?keahlian=Basis Data
router.get('/dosen', (req, res) => {
  const keahlian = (req.query.keahlian || '').trim().toLowerCase();

  const hasil = keahlian
    ? dosen.filter((d) => d.keahlian.toLowerCase() === keahlian)
    : dosen;

  res.json({ total: hasil.length, data: hasil });
});

module.exports = router;
```

### 5.8 `cek-environment.js`: cek environment

```js
// Jalankan dengan: npm run cek
const fs = require('fs');
const path = require('path');

function versiPaket(nama) {
  try {
    const p = require.resolve(`${nama}/package.json`, { paths: [__dirname] });
    return JSON.parse(fs.readFileSync(p, 'utf8')).version;
  } catch {
    return 'BELUM TERPASANG (jalankan: npm install)';
  }
}

console.log('=== CEK ENVIRONMENT ===');
console.log('Node.js        :', process.version);
console.log('Sistem Operasi :', process.platform);
console.log('Folder proyek  :', __dirname);
console.log('Express        :', versiPaket('express'));
console.log('EJS            :', versiPaket('ejs'));
console.log(
  'package.json   :',
  fs.existsSync(path.join(__dirname, 'package.json')) ? 'ADA' : 'TIDAK ADA'
);

const nodeMajor = parseInt(process.versions.node.split('.')[0], 10);
console.log(
  'Status         :',
  nodeMajor >= 18 ? 'OK, Node.js sudah memenuhi syarat' : 'Update Node.js ke 18 atau lebih baru'
);
```

### 5.9 `routes-list.js`: daftar route (setara `route:list`)

```js
// Jalankan dengan: npm run routes
const web = require('./routes/web');
const admin = require('./routes/admin');
const api = require('./routes/api');

function cetak(prefix, router) {
  const baris = [];
  router.stack.forEach((layer) => {
    if (!layer.route) return;
    const metode = Object.keys(layer.route.methods).map((m) => m.toUpperCase()).join('|');
    [].concat(layer.route.path).forEach((p) => {
      const url = (prefix + p).replace(/\/$/, '') || '/';
      baris.push({ Metode: metode, URL: url });
    });
  });
  return baris;
}

const semua = [
  ...cetak('', web),
  ...cetak('/admin', admin),
  ...cetak('/api', api),
  { Metode: 'ANY', URL: '(lainnya) -> 404 kustom' },
];

console.table(semua);
```

### 5.10 `views/partials/header.ejs`

```html
<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title><%= judul %> | Prodi <%= prodi.nama %></title>
  <link rel="stylesheet" href="/css/style.css">
</head>
<body>
  <header class="topbar">
    <div class="container topbar-inner">
      <a class="brand" href="/">
        <!-- GANTI FOTO: logo program studi / kampus.
             Simpan file Anda di express/public/img/logo.png (nama file harus sama,
             atau ubah src di bawah). Jika file belum ada, otomatis tampil placeholder. -->
        <img src="/img/logo.png" alt="Logo" class="logo"
             onerror="this.onerror=null;this.src='/img/placeholder.svg'">
        <span>Prodi <%= prodi.nama %></span>
      </a>
      <nav>
        <a href="/profil" class="<%= (path === '/' || path === '/profil') ? 'aktif' : '' %>">Profil</a>
        <a href="/dosen" class="<%= path.startsWith('/dosen') ? 'aktif' : '' %>">Dosen</a>
        <a href="/berita" class="<%= path.startsWith('/berita') ? 'aktif' : '' %>">Berita</a>
        <a href="/kontak" class="<%= path.startsWith('/kontak') ? 'aktif' : '' %>">Kontak</a>
        <a href="/admin/dashboard" class="<%= path.startsWith('/admin') ? 'aktif' : '' %>">Admin</a>
      </nav>
    </div>
  </header>
  <main class="container">
```

### 5.11 `views/partials/footer.ejs`

```html
  </main>
  <footer class="footer">
    <div class="container">
      <p><strong><%= prodi.kampus %></strong> · <%= prodi.fakultas %></p>
      <p><%= prodi.alamat %></p>
      <p><%= prodi.email %> · <%= prodi.telepon %></p>
    </div>
  </footer>
</body>
</html>
```

### 5.12 `views/beranda.ejs`

```html
<%- include('partials/header', { judul }) %>

<section class="hero">
  <div class="hero-teks">
    <p class="label">Selamat datang</p>
    <h1>Program Studi <%= prodi.nama %></h1>
    <p><%= prodi.fakultas %> · <%= prodi.kampus %></p>
    <a class="tombol" href="/dosen">Lihat Dosen</a>
  </div>
  <!-- GANTI FOTO: foto utama (gedung kampus / kegiatan mahasiswa) di beranda.
       Simpan di express/public/img/hero.jpg. Ukuran saran: 1200x800 px. -->
  <img src="/img/hero.jpg" alt="Foto program studi" class="hero-img"
       onerror="this.onerror=null;this.src='/img/placeholder.svg'">
</section>

<section class="kartu">
  <h2>Visi</h2>
  <p><%= prodi.visi %></p>
</section>

<section class="kartu">
  <h2>Misi</h2>
  <ol>
    <% prodi.misi.forEach(function (m) { %>
      <li><%= m %></li>
    <% }) %>
  </ol>
</section>

<%- include('partials/footer') %>
```

### 5.13 `views/dosen.ejs`

```html
<%- include('partials/header', { judul }) %>

<h1>Daftar Dosen</h1>

<!-- FORM FILTER (method GET -> menghasilkan /dosen?keahlian=...) -->
<form method="GET" action="/dosen" class="filter">
  <label for="keahlian">Filter keahlian:</label>
  <select name="keahlian" id="keahlian">
    <option value="">Semua</option>
    <% daftarKeahlian.forEach(function (k) { %>
      <option value="<%= k %>" <%= k.toLowerCase() === keahlianDipilih.toLowerCase() ? 'selected' : '' %>><%= k %></option>
    <% }) %>
  </select>
  <button type="submit" class="tombol">Terapkan</button>
  <a href="/dosen">Reset</a>
</form>

<p>Menampilkan <strong><%= dosen.length %></strong> dosen.</p>

<% if (dosen.length === 0) { %>
  <p class="kosong">Tidak ada dosen dengan keahlian tersebut.</p>
<% } %>

<div class="grid">
  <% dosen.forEach(function (d) { %>
    <article class="kartu dosen">
      <!-- GANTI FOTO: foto dosen. Nama file diatur di data/dosen.js (kolom "foto"),
           file-nya disimpan di express/public/img/dosen/ -->
      <img src="/img/dosen/<%= d.foto %>" alt="<%= d.nama %>"
           onerror="this.onerror=null;this.src='/img/placeholder.svg'">
      <h3><%= d.nama %></h3>
      <p class="badge"><%= d.keahlian %></p>
      <a href="/dosen/<%= d.nidn %>">Lihat detail</a>
    </article>
  <% }) %>
</div>

<%- include('partials/footer') %>
```

### 5.14 `views/dosen-detail.ejs`

```html
<%- include('partials/header', { judul }) %>

<a href="/dosen">&larr; Kembali ke daftar dosen</a>

<section class="kartu detail">
  <!-- GANTI FOTO: foto dosen (sama dengan di daftar dosen, diatur di data/dosen.js) -->
  <img src="/img/dosen/<%= d.foto %>" alt="<%= d.nama %>"
       onerror="this.onerror=null;this.src='/img/placeholder.svg'">
  <div>
    <h1><%= d.nama %></h1>
    <p class="badge"><%= d.keahlian %></p>
    <table class="tabel">
      <tr><th>NIDN</th><td><%= d.nidn %></td></tr>
      <tr><th>Email</th><td><%= d.email %></td></tr>
    </table>
    <p><%= d.bio %></p>
  </div>
</section>

<%- include('partials/footer') %>
```

### 5.15 `views/berita.ejs`

```html
<%- include('partials/header', { judul }) %>

<h1>Berita: <%= kategori.charAt(0).toUpperCase() + kategori.slice(1) %></h1>

<div class="tab">
  <% kategoriValid.forEach(function (k) { %>
    <a href="/berita/<%= k %>" class="<%= k === kategori ? 'aktif' : '' %>"><%= k %></a>
  <% }) %>
</div>

<% if (daftar.length === 0) { %>
  <p class="kosong">Belum ada berita di kategori ini.</p>
<% } %>

<% daftar.forEach(function (b) { %>
  <article class="kartu">
    <p class="badge"><%= b.kategori %> · <%= b.tanggal %></p>
    <h3><%= b.judul %></h3>
    <p><%= b.ringkasan %></p>
  </article>
<% }) %>

<%- include('partials/footer') %>
```

### 5.16 `views/kontak.ejs`

```html
<%- include('partials/header', { judul }) %>

<h1>Hubungi Kami</h1>

<% if (terkirim) { %>
  <div class="sukses">Terima kasih, <strong><%= data.nama %></strong>! Pesan Anda sudah kami terima.</div>
<% } %>

<!-- FORM KONTAK (method POST -> ditangani router.post('/kontak')) -->
<form method="POST" action="/kontak" class="form kartu">
  <label for="nama">Nama</label>
  <input type="text" id="nama" name="nama" required>

  <label for="email">Email</label>
  <input type="email" id="email" name="email" required>

  <label for="pesan">Pesan</label>
  <textarea id="pesan" name="pesan" rows="5" required></textarea>

  <button type="submit" class="tombol">Kirim</button>
</form>

<%- include('partials/footer') %>
```

### 5.17 `views/admin/dashboard.ejs`

```html
<%- include('../partials/header', { judul }) %>

<h1>Dashboard Admin</h1>

<div class="tab">
  <a href="/admin/dashboard" class="aktif">Dashboard</a>
  <a href="/admin/pengaturan">Pengaturan</a>
</div>

<div class="grid">
  <div class="kartu statistik">
    <p>Total Dosen</p>
    <strong><%= totalDosen %></strong>
  </div>
  <div class="kartu statistik">
    <p>Total Berita</p>
    <strong><%= totalBerita %></strong>
  </div>
</div>

<%- include('../partials/footer') %>
```

### 5.18 `views/admin/pengaturan.ejs`

```html
<%- include('../partials/header', { judul }) %>

<h1>Pengaturan Admin</h1>

<div class="tab">
  <a href="/admin/dashboard">Dashboard</a>
  <a href="/admin/pengaturan" class="aktif">Pengaturan</a>
</div>

<section class="kartu">
  <table class="tabel">
    <tr><th>Nama Prodi</th><td><%= prodi.nama %></td></tr>
    <tr><th>Fakultas</th><td><%= prodi.fakultas %></td></tr>
    <tr><th>Kampus</th><td><%= prodi.kampus %></td></tr>
    <tr><th>Email</th><td><%= prodi.email %></td></tr>
  </table>
  <p><small>Untuk mengubah data ini, edit file <code>data/prodi.js</code>.</small></p>
</section>

<%- include('../partials/footer') %>
```

### 5.19 `views/404.ejs`: halaman 404 kustom

```html
<%- include('partials/header', { judul }) %>

<section class="error404">
  <h1>404</h1>
  <h2>Halaman tidak ditemukan</h2>
  <p>Alamat <code><%= path %></code> tidak tersedia, atau parameter yang Anda masukkan tidak valid.</p>
  <a class="tombol" href="/">Kembali ke Beranda</a>
</section>

<%- include('partials/footer') %>
```

### 5.20 `public/css/style.css`

```css
* { box-sizing: border-box; }

body {
  margin: 0;
  font-family: "Segoe UI", Arial, sans-serif;
  background: #f5f4ef;
  color: #1b2a41;
  line-height: 1.6;
}

.container { max-width: 1000px; margin: 0 auto; padding: 0 20px; }
main.container { padding-top: 24px; padding-bottom: 40px; min-height: 70vh; }

a { color: #2a5ea8; }
h1, h2, h3 { line-height: 1.25; }

/* Header */
.topbar { background: #14213d; }
.topbar-inner { display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap; gap: 10px; padding-top: 12px; padding-bottom: 12px; }
.brand { display: flex; align-items: center; gap: 10px; color: #fff; text-decoration: none; font-weight: 700; }
.logo { width: 40px; height: 40px; object-fit: contain; border-radius: 6px; background: #fff; }
nav a { color: #cfd8e6; text-decoration: none; margin-left: 16px; padding: 4px 0; }
nav a:hover, nav a.aktif { color: #fca75b; border-bottom: 2px solid #fca75b; }

/* Hero */
.hero { display: grid; grid-template-columns: 1fr 1fr; gap: 24px; align-items: center; margin-bottom: 24px; }
.hero-img { width: 100%; height: 280px; object-fit: cover; border-radius: 12px; background: #dbe4ee; }
.label { color: #b84a14; font-weight: 700; text-transform: uppercase; letter-spacing: 1px; font-size: 13px; margin: 0; }

/* Komponen umum */
.kartu { background: #fff; border: 1px solid #d8d6cc; border-radius: 10px; padding: 18px 20px; margin-bottom: 16px; }
.grid { display: grid; grid-template-columns: repeat(auto-fill, minmax(220px, 1fr)); gap: 16px; }
.badge { display: inline-block; background: #e8eef7; color: #2a5ea8; padding: 2px 10px; border-radius: 20px; font-size: 13px; margin: 0 0 8px; }
.tombol { display: inline-block; background: #b84a14; color: #fff; border: 0; padding: 9px 18px; border-radius: 8px; text-decoration: none; cursor: pointer; font-size: 15px; }
.tombol:hover { background: #963a0d; }
.kosong { color: #777; font-style: italic; }

/* Dosen */
.dosen { text-align: center; }
.dosen img { width: 100%; height: 180px; object-fit: cover; border-radius: 8px; background: #dbe4ee; }
.filter { display: flex; align-items: center; gap: 10px; flex-wrap: wrap; margin-bottom: 14px; }
.filter select { padding: 8px; border-radius: 6px; border: 1px solid #bbb; }
.detail { display: grid; grid-template-columns: 240px 1fr; gap: 24px; margin-top: 12px; }
.detail img { width: 100%; border-radius: 10px; background: #dbe4ee; }

/* Tabel */
.tabel { border-collapse: collapse; width: 100%; margin: 10px 0; }
.tabel th, .tabel td { text-align: left; padding: 8px 10px; border-bottom: 1px solid #e3e1d8; }
.tabel th { width: 140px; color: #555; }

/* Tab */
.tab { margin: 10px 0 18px; display: flex; gap: 8px; flex-wrap: wrap; }
.tab a { padding: 6px 14px; border-radius: 20px; background: #e4e2d9; text-decoration: none; color: #1b2a41; text-transform: capitalize; }
.tab a.aktif { background: #14213d; color: #fff; }

/* Form */
.form { max-width: 520px; }
.form label { display: block; margin: 12px 0 4px; font-weight: 600; }
.form input, .form textarea { width: 100%; padding: 9px; border: 1px solid #bbb; border-radius: 6px; font: inherit; }
.form button { margin-top: 14px; }
.sukses { background: #e3f6e8; border: 1px solid #9bd3aa; padding: 12px 16px; border-radius: 8px; margin-bottom: 16px; }

/* Statistik admin */
.statistik p { margin: 0; color: #666; }
.statistik strong { font-size: 40px; color: #14213d; }

/* 404 */
.error404 { text-align: center; padding: 50px 0; }
.error404 h1 { font-size: 90px; margin: 0; color: #b84a14; }

/* Footer */
.footer { background: #14213d; color: #cfd8e6; padding: 18px 0; font-size: 14px; }
.footer p { margin: 2px 0; }

/* Responsif */
@media (max-width: 700px) {
  .hero, .detail { grid-template-columns: 1fr; }
}
```

### 5.21 `public/img/placeholder.svg`: gambar cadangan

Gambar ini muncul otomatis jika foto Anda belum ada, sehingga website tidak menampilkan gambar rusak.

```xml
<svg xmlns="http://www.w3.org/2000/svg" width="400" height="300" viewBox="0 0 400 300">
  <rect width="400" height="300" fill="#dbe4ee"/>
  <circle cx="200" cy="120" r="45" fill="#9fb3c8"/>
  <rect x="110" y="180" width="180" height="90" rx="45" fill="#9fb3c8"/>
</svg>
```

### 5.22 `.gitignore`: di folder `profil-prodi/` (satu level di atas `express/`)

```
node_modules/
.env
.DS_Store
```

Ini yang membuat `node_modules` **tidak ikut** ter-upload, sesuai syarat tugas.

---

## 6. Menjalankan & Menguji Website

Dari folder `express/`:

```bash
npm run dev
```

Output yang benar: `Server berjalan di http://localhost:3000`. Buka alamat itu di browser. Hentikan server dengan `Ctrl + C`.

### Daftar uji

| Buka URL | Hasil yang diharapkan |
|---|---|
| `http://localhost:3000/` | Beranda, visi dan misi |
| `http://localhost:3000/profil` | Sama dengan beranda |
| `http://localhost:3000/dosen` | Semua dosen |
| `http://localhost:3000/dosen?keahlian=Basis Data` | Hanya dosen Basis Data |
| `http://localhost:3000/dosen/0012058801` | Detail dosen (NIDN 10 digit, ada) |
| `http://localhost:3000/dosen/123` | **404** (bukan 10 digit) |
| `http://localhost:3000/dosen/9999999999` | **404** (10 digit tapi tidak ada) |
| `http://localhost:3000/berita` | Berita kategori `terbaru` (default) |
| `http://localhost:3000/berita/prestasi` | Berita prestasi |
| `http://localhost:3000/berita/asal` | **404** |
| `http://localhost:3000/kontak` | Form kontak (isi lalu kirim) |
| `http://localhost:3000/admin/dashboard` | Dashboard admin |
| `http://localhost:3000/admin/pengaturan` | Pengaturan admin |
| `http://localhost:3000/api/dosen` | JSON daftar dosen |
| `http://localhost:3000/apa-saja` | **404 kustom** |

---

## 7. Bagian yang Bisa Anda Ganti (Foto & Konten)

Semua tempat foto di kode sudah diberi komentar `GANTI FOTO`.

| Foto | Lokasi file foto | Ditampilkan oleh | Cara ganti |
|---|---|---|---|
| Logo | `express/public/img/logo.png` | `views/partials/header.ejs` | Timpa/ganti file dengan nama yang sama |
| Foto utama beranda | `express/public/img/hero.jpg` | `views/beranda.ejs` | Timpa/ganti file dengan nama yang sama |
| Foto dosen | `express/public/img/dosen/` | `views/dosen.ejs` & `views/dosen-detail.ejs` | Taruh foto di folder itu, lalu samakan nama di kolom `foto` pada `data/dosen.js` |
| Foto cadangan | `express/public/img/placeholder.svg` | semua halaman (otomatis) | Tidak perlu diubah |

Contoh: foto dosen bernama `pak-andi.png`. Simpan di `public/img/dosen/pak-andi.png`, lalu di `data/dosen.js` ubah `foto: 'dosen-1.jpg'` menjadi `foto: 'pak-andi.png'`.

Konten lain yang perlu diubah:

- **Nama prodi, visi, misi, alamat, email**: `data/prodi.js`
- **Data dosen** (nama, NIDN, keahlian): `data/dosen.js`. NIDN harus tetap **10 digit angka**.
- **Berita**: `data/berita.js`
- **Warna website**: bagian atas `public/css/style.css` (cari kode warna seperti `#14213d` dan `#b84a14`)

Tips: gunakan foto berukuran wajar (di bawah 1 MB) supaya repo GitHub tidak berat. Setelah mengganti foto, refresh browser dengan `Ctrl + F5`.

---

## 8. Screenshot yang Harus Dikumpulkan

Jalankan di folder `express/`, lalu screenshot hasilnya:

```bash
node -v
npm -v
git --version
npm run cek
npm run routes
```

1. **Cek environment**: output `npm run cek` (disertai `node -v`, `npm -v`).
2. **Daftar route** (pengganti `route:list`): output `npm run routes`.
3. **Minimal 3 halaman di browser**, misalnya: beranda `/`, daftar dosen `/dosen`, dan halaman 404 kustom (juga bisa Berita/Kontak/Admin). Pastikan bilah alamat browser (URL) terlihat di screenshot.

---

## 9. Upload ke GitHub

### 9.1 Buat repository kosong di GitHub

1. Login ke https://github.com
2. Klik tombol **+** (kanan atas) → **New repository**
3. Repository name: `profil-prodi`
4. Pilih **Public** (agar bisa dilihat dosen)
5. **Jangan** centang *Add a README*, *.gitignore*, atau *license* (repo harus kosong)
6. Klik **Create repository**

### 9.2 Pastikan `.gitignore` dan README ada

Struktur akhir di `profil-prodi/`: `.gitignore`, `README.md` (file panduan ini), dan folder `express/`.

### 9.3 Inisialisasi Git dan push

Di terminal VS Code, **pindah ke folder `profil-prodi`** (satu level di atas `express`):

```bash
cd ..
git init
git status
```

Pastikan di daftar `git status` **tidak ada** `node_modules`. Jika aman, lanjutkan:

```bash
git add .
git commit -m "Tugas mandiri: website profil prodi dengan Express"
git branch -M main
git remote add origin https://github.com/USERNAME_ANDA/profil-prodi.git
git push -u origin main
```

Ganti `USERNAME_ANDA` dengan username GitHub Anda (salin URL persisnya dari halaman repo yang baru dibuat).

### 9.4 Login saat push

Saat `git push` pertama kali, biasanya muncul jendela login GitHub di browser. Ikuti saja sampai selesai. Jika diminta *username* dan *password* di terminal, **password harus berupa Personal Access Token**, bukan password akun:
GitHub → **Settings → Developer settings → Personal access tokens → Tokens (classic) → Generate new token** → centang `repo` → salin token dan tempel sebagai password.

### 9.5 Verifikasi

Refresh halaman repo di GitHub. Pastikan:

- Ada folder `express/` berisi `app.js`, `routes/`, `views/`, `public/`, `data/`, dan `package.json`
- **Tidak ada** folder `node_modules`
- `README.md` tampil di halaman depan repo

### 9.6 Jika Anda mengubah sesuatu setelah push

```bash
git add .
git commit -m "Ganti foto dan perbarui data dosen"
git push
```

### 9.7 Cara orang lain menjalankan proyek Anda

Karena `node_modules` tidak di-upload, siapa pun yang mengunduh repo harus menjalankan:

```bash
git clone https://github.com/USERNAME_ANDA/profil-prodi.git
cd profil-prodi/express
npm install
npm start
```

---

## 10. Pengumpulan di LMS & Checklist

Kumpulkan di LMS:

- Link repo GitHub (`https://github.com/USERNAME_ANDA/profil-prodi`)
- Screenshot `npm run cek` dan `npm run routes`
- Screenshot minimal 3 halaman di browser

Checklist sebelum mengumpulkan:

- [ ] `node -v`, `npm -v`, dan `npm run cek` berhasil
- [ ] Semua route di tabel bagian 6 berjalan sesuai harapan
- [ ] `/dosen/123` dan `/apa-saja` menampilkan 404 kustom
- [ ] Prefix `/admin` bekerja (`/admin/dashboard` dan `/admin/pengaturan`)
- [ ] `/api/dosen` menampilkan JSON
- [ ] Foto sudah diganti sesuai keinginan (atau placeholder tampil normal)
- [ ] `node_modules` tidak ada di GitHub
- [ ] Repo berstatus **Public** dan link bisa dibuka

---

## 11. Troubleshooting

| Masalah | Penyebab & solusi |
|---|---|
| `'node' is not recognized` | Node.js belum terpasang atau terminal belum direstart. Instal Node LTS, restart VS Code. |
| `Cannot find module 'express'` | Belum `npm install`, atau terminal tidak berada di folder `express/`. Jalankan `cd express` lalu `npm install express@4 ejs`. |
| `Failed to lookup view "..."` | Nama/lokasi file `.ejs` salah, atau folder `views` salah tempat. Periksa struktur di bagian 4. |
| `EADDRINUSE: address already in use :::3000` | Port 3000 sedang dipakai. Matikan server lain (`Ctrl + C`) atau jalankan `PORT=3001 npm start`. Di PowerShell: `$env:PORT=3001; npm start`. |
| `node --watch` tidak dikenali | Node terlalu lama. Update Node ke 18.11+ atau pakai `npm start`. |
| Foto tidak muncul | Cek nama file (huruf besar/kecil berpengaruh) dan lokasi folder. Placeholder akan tampil sebagai cadangan. |
| CSS tidak berubah | Refresh paksa dengan `Ctrl + F5`. |
| `git push` ditolak / minta login | Gunakan Personal Access Token (bagian 9.4). |
| `remote origin already exists` | Jalankan `git remote set-url origin https://github.com/USERNAME_ANDA/profil-prodi.git`. |
| `node_modules` ikut ter-commit | Pastikan `.gitignore` ada **sebelum** `git add .`. Jika sudah terlanjur: `git rm -r --cached express/node_modules` lalu commit ulang. |

---

Selamat mengerjakan! 🚀
