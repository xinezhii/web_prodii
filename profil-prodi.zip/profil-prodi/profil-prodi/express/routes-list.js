// Jalankan dengan: npm run routes
const web = require('./routes/web');
const admin = require('./routes/admin');
const api = require('./routes/api');

function cetak(prefix, router) {
  const baris = [];
  router.stack.forEach((layer) => {
    if (!layer.route) return;
    const metode = Object.keys(layer.route.methods).map((m) => m.toUpperCase()).join('|');
    [].concat(layer.route.path).forEach((p) => {
      const url = (prefix + p).replace(/\/$/, '') || '/';
      baris.push({ Metode: metode, URL: url });
    });
  });
  return baris;
}

const semua = [
  ...cetak('', web),
  ...cetak('/admin', admin),
  ...cetak('/api', api),
  { Metode: 'ANY', URL: '(lainnya) -> 404 kustom' },
];

console.table(semua);
