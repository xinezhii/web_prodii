// NIDN harus 10 digit angka.
// "foto" = nama file di folder public/img/dosen/
// GANTI FOTO: taruh foto dosen di express/public/img/dosen/ lalu samakan nama filenya di sini.
const koleksi = require('../lib/koleksi');

// Dosen baru/ubahan dari halaman /admin/dosen disimpan di data/dosen.json
module.exports = koleksi('dosen', [
  {
    nidn: '1110109101',
    nama: 'Wahyuni, S.Kom., M.Kom.',
    keahlian: 'Pembelajaran Mesin',
    email: 'wahyuni@wicida.ac.id',
    bio: 'Dosen pengampu mata kuliah Pembelajaran Mesin.',
    foto: 'dosen-1.jpg',
  },
  {
    nidn: '1126038303',
    nama: 'Pitrasacha Adytia, S.T., M.T.',
    keahlian: 'Pemrograman Berbasis Kerangka Kerja',
    email: 'pitra@wicida.ac.id',
    bio: 'Dosen pengampu mata kuliah Pemrograman Berbasis Kerangka Kerja.',
    foto: 'dosen-2.jpg',
  },
  {
    nidn: '1112057201', // <- periksa lagi, sebelumnya 11 digit (11120057201)
    nama: 'Dr. H. Nursobah, S.Kom., M.Kom., IPM., ASEAN Eng.',
    keahlian: 'Kewirausahaan',
    email: 'nursb@yahoo.com',
    bio: 'Dosen pengampu mata kuliah Kewirausahaan.',
    foto: 'dosen-3.jpg',
  },
  {
    nidn: '1103058302',
    nama: 'Amelia Yusnita, S.Kom., M.Kom.',
    keahlian: 'Metode Penelitian',
    email: 'amelia@wicida.ac.id',
    bio: 'Dosen pengampu mata kuliah Metode Penelitian.',
    foto: 'dosen-4.jpg',
  },
  {
    nidn: '1113028601',
    nama: 'Dr. Heny Pratiwi, S.Kom., M.Pd., M.TI.',
    keahlian: 'Kecerdasan Buatan (Artificial Intelligence)',
    email: 'henypratiwi@wicida.ac.id',
    bio: 'Dosen pengampu mata kuliah Kecerdasan Buatan (Artificial Intelligence).',
    foto: 'dosen-5.jpg',
  },
]);
