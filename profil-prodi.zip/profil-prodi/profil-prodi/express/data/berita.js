// kategori yang valid: akademik, prestasi, kegiatan
// "terbaru" = semua berita (default)
const koleksi = require('../lib/koleksi');

const bawaan = [
  {
    judul: 'Pendaftaran Mahasiswa Baru Dibuka',
    kategori: 'akademik',
    tanggal: '2026-10-01',
    ringkasan: 'Pendaftaran mahasiswa baru gelombang kedua telah dibuka hingga akhir bulan.',
  },
  {
    judul: 'Mahasiswa Juara 1 Lomba Pemrograman Nasional',
    kategori: 'prestasi',
    tanggal: '2026-09-20',
    ringkasan: 'Tim mahasiswa berhasil meraih juara pertama pada kompetisi tingkat nasional.',
  },
  {
    judul: 'Workshop Pengembangan Web Modern',
    kategori: 'kegiatan',
    tanggal: '2026-09-12',
    ringkasan: 'Workshop dua hari membahas Node.js, Express, dan deployment aplikasi.',
  },
  {
    judul: 'Jadwal Ujian Tengah Semester Dirilis',
    kategori: 'akademik',
    tanggal: '2026-09-05',
    ringkasan: 'Jadwal UTS semester ganjil sudah dapat dilihat oleh mahasiswa.',
  },
];

// Berita baru/ubahan dari halaman /admin/berita disimpan di data/berita.json
const berita = koleksi('berita', bawaan.map((b, i) => ({ id: i + 1, ...b })));
Object.defineProperty(berita, 'kategori', { enumerable: false, value: ['akademik', 'prestasi', 'kegiatan'] });
module.exports = berita;
