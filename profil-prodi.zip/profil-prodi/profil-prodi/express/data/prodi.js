// Data profil prodi. Nilai bawaan ada di bawah; perubahan dari halaman
// /admin/profil disimpan ke data/prodi.json dan otomatis dibaca saat server mulai.
const fs = require('fs');
const path = require('path');

const FILE = path.join(__dirname, 'prodi.json');

const bawaan = {
  nama: 'Teknik Informatika',
  singkatan: 'TI',
  fakultas: 'Fakultas Teknik',
  kampus: 'STMIK WIDYA CIPTA DHARMA',
  alamat: 'Jl. M.Yamin, Samarinda, Kalimantan Timur',
  email: 'ti@wicida.ac.id',
  telepon: '(0541) 000000',
  sambutan: 'Belajar membangun perangkat lunak, mengolah data, dan menciptakan teknologi yang berguna bagi masyarakat.',
  hero: null, // alamat foto utama beranda (diatur dari halaman admin)
  logo: null, // alamat logo (diatur dari halaman admin)
  visi:
    'Menjadi program studi unggulan yang menghasilkan lulusan kompeten, inovatif, dan berdaya saing di bidang teknologi informasi.',
  misi: [
    'Menyelenggarakan pendidikan yang berkualitas dan sesuai kebutuhan industri.',
    'Melaksanakan penelitian yang bermanfaat bagi pengembangan ilmu dan masyarakat.',
    'Melaksanakan pengabdian kepada masyarakat berbasis teknologi.',
    'Membangun kerja sama dengan industri, pemerintah, dan perguruan tinggi lain.',
  ],
};

let tersimpan = {};
try { tersimpan = JSON.parse(fs.readFileSync(FILE, 'utf8')); } catch { /* belum ada file: pakai bawaan */ }

const prodi = { ...bawaan, ...tersimpan };

// prodi.simpan({...}) mengubah objek yang sama (jadi semua halaman ikut berubah) lalu menulis ke prodi.json
Object.defineProperty(prodi, 'simpan', {
  enumerable: false,
  value(perubahan) {
    Object.assign(prodi, perubahan);
    fs.writeFileSync(FILE, JSON.stringify(prodi, null, 2));
  },
});

module.exports = prodi;
