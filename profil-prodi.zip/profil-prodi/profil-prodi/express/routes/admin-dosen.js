const express = require('express');
const router = express.Router();

const dosen = require('../data/dosen');
const gambar = require('../lib/gambar');

const PESAN = { tambah: 'Dosen ditambahkan.', ubah: 'Perubahan dosen tersimpan.', hapus: 'Dosen dihapus.' };

function form(res, { d = {}, galat = [], baru = true, status = 200 } = {}) {
  const daftarKeahlian = [...new Set(dosen.map((x) => x.keahlian))];
  res.status(status).render('admin/dosen-form', { judul: baru ? 'Tambah Dosen' : 'Ubah Dosen', d, galat, baru, daftarKeahlian });
}

function baca(b) {
  const t = (k) => String(b[k] || '').trim();
  return { nidn: t('nidn'), nama: t('nama'), keahlian: t('keahlian'), email: t('email'), bio: t('bio'), foto: t('foto') };
}

function cek(d, lama) {
  const galat = [];
  if (!/^\d{10}$/.test(d.nidn)) galat.push('NIDN harus tepat 10 digit angka.');
  else if (!lama && dosen.some((x) => x.nidn === d.nidn)) galat.push('NIDN ini sudah terdaftar.');
  if (!d.nama) galat.push('Nama wajib diisi.');
  if (!d.keahlian) galat.push('Keahlian wajib diisi.');
  if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(d.email)) galat.push('Format email belum benar.');
  if (d.nama.length > 120 || d.keahlian.length > 80 || d.bio.length > 600) galat.push('Ada isian yang terlalu panjang.');
  if (d.foto && d.foto !== (lama && lama.foto) && !gambar.ada(d.foto)) galat.push('Foto tidak valid, silakan unggah ulang.');
  return galat;
}

router.get('/', (req, res) => {
  res.render('admin/dosen-daftar', { judul: 'Kelola Dosen', dosen, pesan: PESAN[req.query.ok] || '' });
});

router.get('/tambah', (req, res) => form(res));

router.post('/tambah', (req, res) => {
  const d = baca(req.body);
  const galat = cek(d, null);
  if (galat.length) return form(res, { d, galat, status: 400 });
  dosen.push(d);
  dosen.simpan();
  res.redirect('/admin/dosen?ok=tambah');
});

// unggah foto dosen: browser mengirim gambar yang sudah dikecilkan, server mengembalikan alamatnya
router.post('/foto', express.json({ limit: '9mb' }), (req, res) => {
  try { res.json({ url: gambar.simpan('dosen', (req.body || {}).data) }); }
  catch (e) { res.status(400).json({ galat: e.message }); }
});

router.get('/:nidn/ubah', (req, res, next) => {
  const d = dosen.find((x) => x.nidn === req.params.nidn);
  if (!d) return next();
  form(res, { d, baru: false });
});

router.post('/:nidn/ubah', (req, res, next) => {
  const lama = dosen.find((x) => x.nidn === req.params.nidn);
  if (!lama) return next();
  const d = baca(req.body);
  d.nidn = lama.nidn; // NIDN dipakai di URL, jadi tidak diubah
  const galat = cek(d, lama);
  if (galat.length) return form(res, { d, galat, baru: false, status: 400 });
  if (lama.foto !== d.foto) gambar.hapus(lama.foto);
  Object.assign(lama, d);
  dosen.simpan();
  res.redirect('/admin/dosen?ok=ubah');
});

router.post('/:nidn/hapus', (req, res, next) => {
  const i = dosen.findIndex((x) => x.nidn === req.params.nidn);
  if (i < 0) return next();
  gambar.hapus(dosen[i].foto);
  dosen.splice(i, 1);
  dosen.simpan();
  res.redirect('/admin/dosen?ok=hapus');
});

module.exports = router;
