const express = require('express');
const router = express.Router();

const dosen = require('../data/dosen');
const berita = require('../data/berita');

// 1) Beranda: dua URL menuju halaman yang sama
router.get(['/', '/profil'], (req, res) => {
  res.render('beranda', { judul: 'Beranda' });
});

// 2) Daftar dosen + filter keahlian: /dosen?keahlian=Basis Data
router.get('/dosen', (req, res) => {
  const keahlian = (req.query.keahlian || '').trim();

  const daftarKeahlian = [...new Set(dosen.map((d) => d.keahlian))];

  const hasil = keahlian
    ? dosen.filter((d) => d.keahlian.toLowerCase() === keahlian.toLowerCase())
    : dosen;

  res.render('dosen', {
    judul: 'Dosen',
    dosen: hasil,
    daftarKeahlian,
    keahlianDipilih: keahlian,
  });
});

// 3) Detail dosen: NIDN harus tepat 10 digit angka, selain itu 404
router.get('/dosen/:nidn', (req, res, next) => {
  const { nidn } = req.params;

  if (!/^\d{10}$/.test(nidn)) return next(); // bukan 10 digit -> 404

  const d = dosen.find((x) => x.nidn === nidn);
  if (!d) return next(); // 10 digit tapi tidak ada datanya -> 404

  res.render('dosen-detail', { judul: d.nama, d });
});

// 4) Berita: /berita atau /berita/prestasi. Default "terbaru"
router.get('/berita/:kategori?', (req, res, next) => {
  const kategori = (req.params.kategori || 'terbaru').toLowerCase();
  const kategoriValid = ['terbaru', ...berita.kategori];

  if (!kategoriValid.includes(kategori)) return next(); // kategori asing -> 404

  const daftar =
    kategori === 'terbaru'
      ? [...berita].sort((a, b) => b.tanggal.localeCompare(a.tanggal))
      : berita.filter((b) => b.kategori === kategori).sort((a, b) => b.tanggal.localeCompare(a.tanggal));

  res.render('berita', { judul: 'Berita', kategori, kategoriValid, daftar });
});

// 5) Halaman form kontak (tambahan)
router.get('/kontak', (req, res) => {
  res.render('kontak', { judul: 'Kontak', terkirim: false, data: {} });
});

router.post('/kontak', (req, res) => {
  const { nama, email, pesan } = req.body;
  console.log('Pesan masuk:', { nama, email, pesan });
  res.render('kontak', { judul: 'Kontak', terkirim: true, data: { nama } });
});

module.exports = router;
