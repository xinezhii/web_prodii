const express = require('express');
const crypto = require('crypto');
const fs = require('fs');
const path = require('path');
const router = express.Router();

const dosen = require('../data/dosen');
const berita = require('../data/berita');
const prodi = require('../data/prodi');

// --- Proteksi opsional: jalankan dengan  ADMIN_PASSWORD=rahasia npm start  (user: admin) ---
function sama(a, b) {
  const x = Buffer.from(a), y = Buffer.from(b);
  return x.length === y.length && crypto.timingSafeEqual(x, y);
}
if (!process.env.ADMIN_PASSWORD) {
  console.warn('[peringatan] ADMIN_PASSWORD belum diset: halaman /admin bisa dibuka siapa saja.');
}
router.use((req, res, next) => {
  const pw = process.env.ADMIN_PASSWORD;
  if (!pw) return next();
  const [tipe, b64] = (req.headers.authorization || '').split(' ');
  const [user, ...sisa] = Buffer.from(b64 || '', 'base64').toString().split(':');
  if (tipe === 'Basic' && sama(user, process.env.ADMIN_USER || 'admin') && sama(sisa.join(':'), pw)) return next();
  res.set('WWW-Authenticate', 'Basic realm="Admin Prodi"').status(401).send('Login diperlukan.');
});

// Karena dipasang dengan app.use('/admin', ...), URL aslinya jadi /admin/dashboard
router.get('/dashboard', (req, res) => {
  res.render('admin/dashboard', { judul: 'Dashboard Admin', totalDosen: dosen.length, totalBerita: berita.length });
});

router.get('/pengaturan', (req, res) => {
  res.render('admin/pengaturan', { judul: 'Pengaturan Admin' });
});

// --- Edit profil beranda ---
function tampilkanForm(res, { form = prodi, galat = [], pesan = '', status = 200 } = {}) {
  const misiTeks = Array.isArray(form.misi) ? form.misi.join('\n') : form.misi || '';
  res.status(status).render('admin/profil', { judul: 'Edit Profil', form, misiTeks, galat, pesan });
}

router.get('/profil', (req, res) => {
  tampilkanForm(res, { pesan: req.query.ok ? 'Perubahan tersimpan. Beranda sudah diperbarui.' : '' });
});

router.post('/profil', (req, res) => {
  const b = req.body;
  const t = (k) => String(b[k] || '').trim();
  const data = {
    nama: t('nama'), singkatan: t('singkatan'), fakultas: t('fakultas'), kampus: t('kampus'),
    alamat: t('alamat'), email: t('email'), telepon: t('telepon'),
    sambutan: t('sambutan'), visi: t('visi'),
    misi: String(b.misi || '').split(/\r?\n/).map((s) => s.trim()).filter(Boolean),
  };

  const galat = [];
  if (!data.nama) galat.push('Nama program studi wajib diisi.');
  if (!data.kampus) galat.push('Nama kampus wajib diisi.');
  if (data.email && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(data.email)) galat.push('Format email belum benar.');
  if (data.misi.length === 0) galat.push('Isi minimal satu misi (satu misi per baris).');
  if (data.misi.length > 10) galat.push('Misi maksimal 10 baris.');
  if (data.nama.length > 80 || data.sambutan.length > 300 || data.visi.length > 800 || data.misi.some((m) => m.length > 400)) {
    galat.push('Ada isian yang terlalu panjang.');
  }
  if (galat.length) return tampilkanForm(res, { form: data, galat, status: 400 });

  prodi.simpan(data);
  res.redirect('/admin/profil?ok=1');
});

// --- Upload gambar profil (browser mengecilkan gambar lalu mengirim sebagai data URL) ---
const gambar = require('../lib/gambar');
const JENIS = ['hero', 'logo'];

router.post('/profil/gambar', express.json({ limit: '9mb' }), (req, res) => {
  const { jenis, data } = req.body || {};
  if (!JENIS.includes(jenis)) return res.status(400).json({ galat: 'Jenis gambar tidak valid.' });
  try {
    const url = gambar.simpan(jenis, data);
    gambar.hapus(prodi[jenis]);
    prodi.simpan({ [jenis]: url });
    res.json({ url });
  } catch (e) { res.status(400).json({ galat: e.message }); }
});

router.post('/profil/gambar/hapus', express.json(), (req, res) => {
  const { jenis } = req.body || {};
  if (!JENIS.includes(jenis)) return res.status(400).json({ galat: 'Jenis gambar tidak valid.' });
  gambar.hapus(prodi[jenis]);
  prodi.simpan({ [jenis]: null });
  res.json({ ok: true });
});

// --- Kelola dosen & berita ---
router.use('/dosen', require('./admin-dosen'));
router.use('/berita', require('./admin-berita'));

module.exports = router;
