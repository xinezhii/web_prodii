const express = require('express');
const router = express.Router();

const dosen = require('../data/dosen');

// GET /api/dosen  atau  /api/dosen?keahlian=Basis Data
router.get('/dosen', (req, res) => {
  const keahlian = (req.query.keahlian || '').trim().toLowerCase();

  const hasil = keahlian
    ? dosen.filter((d) => d.keahlian.toLowerCase() === keahlian)
    : dosen;

  res.json({ total: hasil.length, data: hasil });
});

module.exports = router;
