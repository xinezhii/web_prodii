const express = require('express');
const router = express.Router();

const berita = require('../data/berita');

const PESAN = { tambah: 'Berita ditambahkan.', ubah: 'Perubahan berita tersimpan.', hapus: 'Berita dihapus.' };
const hariIni = () => new Date().toISOString().slice(0, 10);

function form(res, { b = { tanggal: hariIni() }, galat = [], baru = true, status = 200 } = {}) {
  res.status(status).render('admin/berita-form', { judul: baru ? 'Tambah Berita' : 'Ubah Berita', b, galat, baru, kategori: berita.kategori });
}

function baca(body) {
  const t = (k) => String(body[k] || '').trim();
  return { judul: t('judul'), kategori: t('kategori'), tanggal: t('tanggal'), ringkasan: t('ringkasan') };
}

function cek(b) {
  const galat = [];
  if (!b.judul) galat.push('Judul wajib diisi.');
  if (!berita.kategori.includes(b.kategori)) galat.push('Pilih kategori yang tersedia.');
  if (!/^\d{4}-\d{2}-\d{2}$/.test(b.tanggal) || isNaN(new Date(b.tanggal))) galat.push('Tanggal belum benar.');
  if (!b.ringkasan) galat.push('Ringkasan wajib diisi.');
  if (b.judul.length > 150 || b.ringkasan.length > 500) galat.push('Ada isian yang terlalu panjang.');
  return galat;
}

const cari = (id) => (/^\d+$/.test(id) ? berita.find((x) => x.id === Number(id)) : undefined);

router.get('/', (req, res) => {
  const urut = [...berita].sort((a, b) => b.tanggal.localeCompare(a.tanggal));
  res.render('admin/berita-daftar', { judul: 'Kelola Berita', daftar: urut, pesan: PESAN[req.query.ok] || '' });
});

router.get('/tambah', (req, res) => form(res));

router.post('/tambah', (req, res) => {
  const b = baca(req.body);
  const galat = cek(b);
  if (galat.length) return form(res, { b, galat, status: 400 });
  berita.push({ id: Math.max(0, ...berita.map((x) => x.id)) + 1, ...b });
  berita.simpan();
  res.redirect('/admin/berita?ok=tambah');
});

router.get('/:id/ubah', (req, res, next) => {
  const b = cari(req.params.id);
  if (!b) return next();
  form(res, { b, baru: false });
});

router.post('/:id/ubah', (req, res, next) => {
  const lama = cari(req.params.id);
  if (!lama) return next();
  const b = baca(req.body);
  const galat = cek(b);
  if (galat.length) return form(res, { b: { ...b, id: lama.id }, galat, baru: false, status: 400 });
  Object.assign(lama, b);
  berita.simpan();
  res.redirect('/admin/berita?ok=ubah');
});

router.post('/:id/hapus', (req, res, next) => {
  const b = cari(req.params.id);
  if (!b) return next();
  berita.splice(berita.indexOf(b), 1);
  berita.simpan();
  res.redirect('/admin/berita?ok=hapus');
});

module.exports = router;
