// Jalankan dengan: npm run cek
const fs = require('fs');
const path = require('path');

function versiPaket(nama) {
  try {
    const p = require.resolve(`${nama}/package.json`, { paths: [__dirname] });
    return JSON.parse(fs.readFileSync(p, 'utf8')).version;
  } catch {
    return 'BELUM TERPASANG (jalankan: npm install)';
  }
}

console.log('=== CEK ENVIRONMENT ===');
console.log('Node.js        :', process.version);
console.log('Sistem Operasi :', process.platform);
console.log('Folder proyek  :', __dirname);
console.log('Express        :', versiPaket('express'));
console.log('EJS            :', versiPaket('ejs'));
console.log(
  'package.json   :',
  fs.existsSync(path.join(__dirname, 'package.json')) ? 'ADA' : 'TIDAK ADA'
);

const nodeMajor = parseInt(process.versions.node.split('.')[0], 10);
console.log(
  'Status         :',
  nodeMajor >= 18 ? 'OK, Node.js sudah memenuhi syarat' : 'Update Node.js ke 18 atau lebih baru'
);
