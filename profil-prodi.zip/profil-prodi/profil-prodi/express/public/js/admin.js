// Konfirmasi sebelum menghapus: <form data-konfirmasi="Hapus ...?">
document.addEventListener('submit', (e) => {
  const pesan = e.target.dataset && e.target.dataset.konfirmasi;
  if (pesan && !confirm(pesan)) e.preventDefault();
});
