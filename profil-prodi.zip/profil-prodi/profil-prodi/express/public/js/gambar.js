// Kecilkan gambar di browser sebelum diunggah. Mengembalikan data URL.
function kecilkan(file, lebarMaks, tipe) {
  return new Promise((ok, gagal) => {
    const img = new Image();
    img.onload = () => {
      const skala = Math.min(1, lebarMaks / img.width);
      const c = document.createElement('canvas');
      c.width = Math.round(img.width * skala);
      c.height = Math.round(img.height * skala);
      c.getContext('2d').drawImage(img, 0, 0, c.width, c.height);
      ok(c.toDataURL(tipe, 0.86));
    };
    img.onerror = () => gagal(new Error('File tidak bisa dibaca sebagai gambar.'));
    img.src = URL.createObjectURL(file);
  });
}
