const express = require('express');
const path = require('path');

const webRoutes = require('./routes/web');
const adminRoutes = require('./routes/admin');
const apiRoutes = require('./routes/api');
const prodi = require('./data/prodi');

const app = express();
const PORT = process.env.PORT || 3000;

// Pengaturan template engine EJS
app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'views'));

// File statis (css, gambar) diambil dari folder public
app.use(express.static(path.join(__dirname, 'public')));

// Agar data dari <form method="POST"> bisa dibaca lewat req.body
app.use(express.urlencoded({ extended: true }));

// Data yang otomatis tersedia di semua file .ejs
app.use((req, res, next) => {
  res.locals.prodi = prodi;
  res.locals.path = req.path; // dipakai untuk menandai menu aktif
  // foto lama = nama file di /img/dosen/, foto unggahan = alamat lengkap /img/uploads/...
  res.locals.fotoDosen = (d) => (!d.foto ? '/img/placeholder.svg' : d.foto.startsWith('/') ? d.foto : '/img/dosen/' + d.foto);
  next();
});

// Grup route
app.use('/admin', adminRoutes); // -> /admin/dashboard, /admin/pengaturan
app.use('/api', apiRoutes);     // -> /api/dosen
app.use('/', webRoutes);        // -> /, /profil, /dosen, /berita, /kontak

// 404 kustom: harus PALING BAWAH, menangkap semua URL yang tidak cocok
app.use((req, res) => {
  res.status(404).render('404', { judul: 'Halaman Tidak Ditemukan' });
});

module.exports = app;

// Server hanya jalan jika file ini dieksekusi langsung (node app.js)
if (require.main === module) {
  app.listen(PORT, () => {
    console.log(`Server berjalan di http://localhost:${PORT}`);
  });
}
